cp /webSvr/appweb.bak /tmp/appweb.conf
ln -s /tmp/appweb.conf /webSvr/appweb.conf
