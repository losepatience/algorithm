﻿//全局变量定义
var m_currentselect = -1;
var b_record = 0;
var b_download = 0;

var m_realplaynum = 1;
var m_localplaynum = 1;
var m_remoteplaynum = -1;
var b_realplaychannel = 0;
var b_localchannel = 0;
var b_remotechannel = 0;

var m_realplaymode = 0;			//实时预览是否有视频
var m_localplaymode = -1;		//播放模式：-16-1/16X；-8-1/8X；-4-1/4X；-2-1/2X；-1-停止；0-暂停；1-正常播放；2-2X；3-帧进；4-4X；8-8X；16-16X
var m_localsoundmode = 0; 	//声音模式：0表示静音，其他值表示音量大小
var m_remoteplaymode = -1;	//播放模式：-8-1/8X；-4-1/4X；-2-1/2X；-1-停止；0-暂停；1-正常播放；2-2X；3-帧进；4-4X；8-8X；
var m_remotesoundmode = 0;	//声音模式
var m_settingwndwidth  = 750;
var m_settingwndheigh = 517;

var alarm_type;
var alarm_info;
var msecs = 600;
var counter = 0;


document.onkeydown   =   function()   
{       
	if(event.keyCode   ==   8)   
	{   
		if(event.srcElement.tagName.toLowerCase()   !=   "input"   
		&&   event.srcElement.tagName.toLowerCase()   !=   "textarea")   
		event.returnValue   =   false;   
	}   
}



function OCXResize()
{
	if(m_currentselect == 5)
	{
		document.getElementById("IPCOcx").height= m_settingwndheigh;
		document.getElementById("IPCOcx").width= m_settingwndwidth;
	}
	else 
	{
		document.getElementById("IPCOcx").height= document.body.clientHeight-180;
		document.getElementById("IPCOcx").width= document.body.clientWidth-20;
	}
}

function blink() 
{
	setAlarm.style.visibility =(setAlarm.style.visibility == "hidden") ? "visible" : "hidden";
	counter +=1;		
}

function AlarmType()
{ 
	alarm_type = IPCOcx.GetAlarmType();
	if(alarm_type == 0)     //判断是否有报警
	{
		document.getElementById("setAlarm").style.visibility="hidden";	
	}
	else
	{
		alarm_info = IPCOcx.GetAlarmToolTip();
		document.getElementById("setAlarm").title = alarm_info;
		document.getElementById("setAlarm").style.visibility="visible";
		setTimeout("blink()", msecs);
	}	
	
}

function LoginDev()
{
	var DevIP = document.domain;
	var DevPort = document.getElementById("t_port").value; 
	var DevUser = document.getElementById("t_username").value; 
	var DevPwd = document.getElementById("t_password").value; 
	
	if(document.getElementById("t_port").value == "")
	{
		alert("登录失败，请重新输入！");
	}
	
	var m_iLoginUserId = IPCOcx.Login(DevIP,DevPort,DevUser,DevPwd);
	
	if(m_iLoginUserId <= 0)
	{
		alert("登录失败，请重新输入！");
	}
	else
	{
		
		document.getElementById("TopMenu").style.visibility="visible";
		document.getElementById("LoginBody").style.display="none";
		document.getElementById("OCXBody").style.display="block";
		var timer1 = self.setInterval("PlayMode()",200);
		var timer2 = self.setInterval("AlarmType()",1000);
		preview();
	}
}

function LoginEnter(e)
{
	var button = document.getElementById("loginbtn");
	if(window.event)
	{
		keyPressed = window.event.keyCode; // IE
	}
	else
	{
		keyPressed = e.which; // Firefox
	}
 
 	if(keyPressed==13)
  {
	 	button.click();            
		e.returnValue = false;
  }
}

function CloseLogin()
{
	window.close();
}


function PlayMode()
{

	if(m_currentselect == 1)
	{
		m_realplaymode = IPCOcx.PreviewGetPlayMode; 
		if(m_realplaymode == 0)
		{
			document.getElementById("b_stop").disabled=true;
			document.getElementById("b_capturepicture").disabled=true;
			document.getElementById("b_record_download_openfile").disabled=true;
			
			document.getElementById("b_stop").style.backgroundImage="url(image/tingzhi1.PNG)";
			document.getElementById("b_capturepicture").style.backgroundImage="url(image/zhuatu1.PNG)";
			document.getElementById("b_record_download_openfile").style.backgroundImage="url(image/luxiang1.PNG)";
			document.getElementById("b_record_download_openfile").title="录像";
			document.getElementById("img_stop").src="image/tingzhi1.PNG";
			document.getElementById("img_capturepicture").src="image/zhuatu1.PNG";
			document.getElementById("img_record_download_openfile").src="image/luxiang1.PNG";
			
		}
		else
		{
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_record_download_openfile").disabled=false;
			
			document.getElementById("b_stop").style.backgroundImage="url(image/tingzhi2.PNG)";
			document.getElementById("b_capturepicture").style.backgroundImage="url(image/zhuatu2.PNG)";
			document.getElementById("b_record_download_openfile").style.backgroundImage="url(image/luxiang2.PNG)";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_record_download_openfile").src="image/luxiang2.PNG";
			
			b_record = IPCOcx.PreviewRecordState;
			if(b_record == 0)
			{
				document.getElementById("b_record_download_openfile").title="录像";
			}
			else if (b_record == 1)
			{
				document.getElementById("b_record_download_openfile").title="停止录像";
			}
		}
	}
	if(m_currentselect == 2)
	{
		m_localplaymode = IPCOcx.LocalGetPlayMode;
		m_localsoundmode = IPCOcx.LocalGetSoundMode;

		if(m_localplaymode < -1)
		{
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=false;
			document.getElementById("b_fast").disabled=false;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;

			document.getElementById("b_capturepicture").style.backgroundImage="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.backgroundImage="url(image/tingzhi2.PNG)";
			document.getElementById("b_pause").style.backgroundImage="url(image/zanting2.PNG)";
			document.getElementById("b_slow").style.backgroundImage="url(image/manfang2.PNG)";
			document.getElementById("b_fast").style.backgroundImage="url(image/kuaifang2.PNG)";
			document.getElementById("b_frame").style.backgroundImage="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.backgroundImage="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.backgroundImage="url(image/yinliangjian2.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_pause").src="image/zanting2.PNG";
			document.getElementById("img_slow").src="image/manfang2.PNG";
			document.getElementById("img_fast").src="image/kuaifang2.PNG";
			document.getElementById("img_frame").src="image/zhuzhen2.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia2.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian2.PNG";
			
			if(m_localplaymode == -2)
			{
				document.getElementById("b_slow").title="1/2X";
			}
			else if (m_localplaymode == -4)
			{
				document.getElementById("b_slow").title="1/4X";
			}
			else if (m_localplaymode == -8)
			{
				document.getElementById("b_slow").title="1/8X";
			}
			else if (m_localplaymode == -16)
			{
				document.getElementById("b_slow").title="1/16X";
			}

		}
		else if(m_localplaymode == -1)
		{
			document.getElementById("b_stop").disabled=true;
			document.getElementById("b_capturepicture").disabled=true;
			document.getElementById("b_pause").disabled=true;
			document.getElementById("b_slow").disabled=true;
			document.getElementById("b_fast").disabled=true;
			document.getElementById("b_frame").disabled=true;
			document.getElementById("b_volumeup").disabled=true;
			document.getElementById("b_volumedown_log").disabled=true;

			document.getElementById("b_capturepicture").style.backgroundImage="url(image/zhuatu1.PNG)";
			document.getElementById("b_stop").style.backgroundImage="url(image/tingzhi1.PNG)";
			document.getElementById("b_pause").style.backgroundImage="url(image/zanting1.PNG)";
			document.getElementById("b_slow").style.backgroundImage="url(image/manfang1.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.backgroundImage="url(image/kuaifang1.PNG)";
			document.getElementById("b_fast").title="快放";
			document.getElementById("b_frame").style.backgroundImage="url(image/zhuzhen1.PNG)";
			document.getElementById("img_volume").src="image/jingyin1.PNG";
			document.getElementById("img_volume").alt="静音";
			document.getElementById("b_volumeup").style.backgroundImage="url(image/yinliangjia1.PNG)";
			document.getElementById("b_volumedown_log").style.backgroundImage="url(image/yinliangjian1.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu1.PNG";
			document.getElementById("img_stop").src="image/tingzhi1.PNG";
			document.getElementById("img_pause").src="image/zanting1.PNG";
			document.getElementById("img_slow").src="image/manfang1.PNG";
			document.getElementById("img_fast").src="image/kuaifang1.PNG";
			document.getElementById("img_frame").src="image/zhuzhen1.PNG";
			document.getElementById("img_volume").src="image/jingyin1.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia1.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian1.PNG";
			
		}
		else if(m_localplaymode == 0 || m_localplaymode == 3)	
		{
			document.getElementById("img_pause").src="image/bofang2.PNG";
			document.getElementById("b_pause").style.background="url(image/bofang2.PNG)";
			document.getElementById("b_pause").title="播放";
			
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=true;
			document.getElementById("b_fast").disabled=true;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi2.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang1.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.background="url(image/kuaifang1.PNG)";
			document.getElementById("b_fast").title="快放";
			
			document.getElementById("b_frame").style.background="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian2.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_slow").src="image/manfang1.PNG";
			document.getElementById("img_fast").src="image/kuaifang1.PNG";
			document.getElementById("img_frame").src="image/zhuzhen2.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia2.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian2.PNG";
			
			
		}
		else if(m_localplaymode == 1)
		{
			document.getElementById("img_pause").src="image/zanting2.PNG";
			document.getElementById("b_pause").style.background="url(image/zanting2.PNG)";
			document.getElementById("b_pause").title="暂停";
			
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=false;
			document.getElementById("b_fast").disabled=false;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi2.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang2.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.background="url(image/kuaifang2.PNG)";
			document.getElementById("b_fast").title="快放";
			document.getElementById("b_frame").style.background="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian2.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_slow").src="image/manfang2.PNG";
			document.getElementById("img_fast").src="image/kuaifang2.PNG";
			document.getElementById("img_frame").src="image/zhuzhen2.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia2.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian2.PNG";
			
		}
		else if(m_localplaymode > 1 && m_localplaymode != 3)
		{
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=false;
			document.getElementById("b_fast").disabled=false;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi2.PNG)";
			document.getElementById("b_pause").style.background="url(image/zanting2.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang2.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.background="url(image/kuaifang2.PNG)";
			document.getElementById("b_frame").style.background="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian2.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_pause").src="image/zanting2.PNG";
			document.getElementById("img_slow").src="image/manfang2.PNG";
			document.getElementById("img_fast").src="image/kuaifang2.PNG";
			document.getElementById("img_frame").src="image/zhuzhen2.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia2.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian2.PNG";
			
			if(m_localplaymode == 2)
			{
				document.getElementById("b_fast").title="2X";
			}
			else if (m_localplaymode == 4)
			{
				document.getElementById("b_fast").title="4X";
			}
			else if (m_localplaymode == 8)
			{
				document.getElementById("b_fast").title="8X";
			}
			else if (m_localplaymode == 16)
			{
				document.getElementById("b_fast").title="16X";
			}
		}
		
		if(m_localsoundmode == 0 || m_localplaymode == -1)
		{
			document.getElementById("img_volume").src="image/jingyin1.PNG";
			document.getElementById("img_volume").alt="静音";
		}
		else if(m_localsoundmode !=0 && m_localplaymode != -1)
		{
			document.getElementById("img_volume").src="image/yinliang2.PNG";
			if(m_localsoundmode == 1)
			{
				document.getElementById("img_volume").alt="1";
			}
			else if (m_localsoundmode == 2)
			{
				document.getElementById("img_volume").alt="2";
			}
			else if (m_localsoundmode == 3)
			{
				document.getElementById("img_volume").alt="3";
			}
			else if (m_localsoundmode == 4)
			{
				document.getElementById("img_volume").alt="4";
			}
		}
	}
	
	if(m_currentselect == 3)
	{
		m_remoteplaymode = IPCOcx.RemoteGetPlayMode;
		m_remotesoundmode = IPCOcx.RemoteGetSoundMode;

		if(m_remoteplaymode < -1)
		{
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=false;
			document.getElementById("b_fast").disabled=false;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi2.PNG)";
			document.getElementById("b_pause").style.background="url(image/zanting2.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang2.PNG)";
			document.getElementById("b_fast").style.background="url(image/kuaifang2.PNG)";
			document.getElementById("b_fast").title="快放";
			document.getElementById("b_frame").style.background="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian2.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_pause").src="image/zanting2.PNG";
			document.getElementById("img_slow").src="image/manfang2.PNG";
			document.getElementById("img_fast").src="image/kuaifang2.PNG";
			document.getElementById("img_frame").src="image/zhuzhen2.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia2.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian2.PNG";
			
			if(m_remoteplaymode == -2)
			{
				document.getElementById("b_slow").title="1/2X";
			}
			else if (m_remoteplaymode == -4)
			{
				document.getElementById("b_slow").title="1/4X";
			}
			else if (m_remoteplaymode == -8)
			{
				document.getElementById("b_slow").title="1/8X";
			}
		}
		else if(m_remoteplaymode == -1)
		{
			document.getElementById("b_capturepicture").disabled=true;
			document.getElementById("b_stop").disabled=true;
			document.getElementById("b_pause").disabled=true;
			document.getElementById("b_slow").disabled=true;
			document.getElementById("b_fast").disabled=true;
			document.getElementById("b_frame").disabled=true;
			document.getElementById("b_volumeup").disabled=true;
			document.getElementById("b_volumedown_log").disabled=true;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu1.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi1.PNG)";
			document.getElementById("b_pause").style.background="url(image/zanting1.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang1.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.background="url(image/kuaifang1.PNG)";
			document.getElementById("b_fast").title="快放";
			document.getElementById("b_frame").style.background="url(image/zhuzhen1.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia1.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian1.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu1.PNG";
			document.getElementById("img_stop").src="image/tingzhi1.PNG";
			document.getElementById("img_pause").src="image/zanting1.PNG";
			document.getElementById("img_slow").src="image/manfang1.PNG";
			document.getElementById("img_fast").src="image/kuaifang1.PNG";
			document.getElementById("img_frame").src="image/zhuzhen1.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia1.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian1.PNG";
		}
		else if(m_remoteplaymode == 0 || m_remoteplaymode == 3)
		{
			document.getElementById("img_pause").src="image/bofang2.PNG";
			document.getElementById("b_pause").style.background="url(image/bofang2.PNG)";
			document.getElementById("b_pause").title="播放";
			
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=true;
			document.getElementById("b_fast").disabled=true;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi2.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang1.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.background="url(image/kuaifang1.PNG)";
			document.getElementById("b_fast").title="快放";
			document.getElementById("b_frame").style.background="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian2.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_slow").src="image/manfang1.PNG";
			document.getElementById("img_fast").src="image/kuaifang1.PNG";
			document.getElementById("img_frame").src="image/zhuzhen2.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia2.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian2.PNG";
		}
		else if(m_remoteplaymode == 1)
		{
			document.getElementById("img_pause").src="image/zanting2.PNG";
			document.getElementById("b_pause").style.background="url(image/zanting2.PNG)";
			document.getElementById("b_pause").title="暂停";
			
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=false;
			document.getElementById("b_fast").disabled=false;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi2.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang2.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.background="url(image/kuaifang2.PNG)";
			document.getElementById("b_fast").title="快放";
			document.getElementById("b_frame").style.background="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian2.PNG)";
			
			document.getElementById("img_capturepicture").src="image/zhuatu2.PNG";
			document.getElementById("img_stop").src="image/tingzhi2.PNG";
			document.getElementById("img_slow").src="image/manfang2.PNG";
			document.getElementById("img_fast").src="image/kuaifang2.PNG";
			document.getElementById("img_frame").src="image/zhuzhen2.PNG";
			document.getElementById("img_volumeup").src="image/yinliangjia2.PNG";
			document.getElementById("img_volumedown_log").src="image/yinliangjian2.PNG";
		}
		else if(m_remoteplaymode > 1 && m_remoteplaymode != 3)
		{
			document.getElementById("b_capturepicture").disabled=false;
			document.getElementById("b_stop").disabled=false;
			document.getElementById("b_pause").disabled=false;
			document.getElementById("b_slow").disabled=false;
			document.getElementById("b_fast").disabled=false;
			document.getElementById("b_frame").disabled=false;
			document.getElementById("b_volumeup").disabled=false;
			document.getElementById("b_volumedown_log").disabled=false;
			
			document.getElementById("b_capturepicture").style.background="url(image/zhuatu2.PNG)";
			document.getElementById("b_stop").style.background="url(image/tingzhi2.PNG)";
			document.getElementById("b_pause").style.background="url(image/zanting2.PNG)";
			document.getElementById("b_slow").style.background="url(image/manfang2.PNG)";
			document.getElementById("b_slow").title="慢放";
			document.getElementById("b_fast").style.background="url(image/kuaifang2.PNG)";
			document.getElementById("b_frame").style.background="url(image/zhuzhen2.PNG)";
			document.getElementById("b_volumeup").style.background="url(image/yinliangjia2.PNG)";
			document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian2.PNG)";

			if(m_remoteplaymode == 2)
			{
				document.getElementById("b_fast").title="2X";
			}
			else if (m_remoteplaymode == 4)
			{
				document.getElementById("b_fast").title="4X";
			}
			else if (m_remoteplaymode == 8)
			{
				document.getElementById("b_fast").title="8X";
			}
		}
		
		if(m_remotesoundmode == 0 || m_remoteplaymode == -1)
		{
			document.getElementById("img_volume").src="image/jingyin1.PNG";
			document.getElementById("img_volume").alt="静音";
		}
		else if(m_remotesoundmode !=0 && m_remoteplaymode != -1 )
		{
			document.getElementById("img_volume").src="image/yinliang2.PNG";
			if(m_remotesoundmode == 1)
			{
				document.getElementById("img_volume").alt="1";
			}
			else if (m_remotesoundmode == 2)
			{
				document.getElementById("img_volume").alt="2";
			}
			else if (m_remotesoundmode == 3)
			{
				document.getElementById("img_volume").alt="3";
			}
			else if (m_remotesoundmode == 4)
			{
				document.getElementById("img_volume").alt="4";
			}
		}
		
		
		
	}
	
}


function preview()
{
	document.getElementById("b_preview").style.background="#333333";
	document.getElementById("b_localplayback").style.background="#666666";
	document.getElementById("b_remoteplayback").style.background="#666666";
	document.getElementById("b_log").style.background="#666666";
	document.getElementById("b_setting").style.background="#666666";
	document.getElementById("b_four").disabled=false;
	document.getElementById("b_nine").disabled=false;
	document.getElementById("b_sixteen").disabled=false;

	if(b_realplaychannel == 0)
	{
		document.getElementById("b_channel").style.background="url(image/single2.PNG)";
		document.getElementById("b_channel").title="操作对单通道有效";
		document.getElementById("img_channel").src="image/single2.PNG";
	}
	else if(b_realplaychannel == 1)
	{
		document.getElementById("b_channel").style.background="url(image/all2.PNG)";
		document.getElementById("b_channel").title="操作对所有通道有效";
		document.getElementById("img_channel").src="image/all2.PNG";
	}
	
	if(m_realplaynum == 1)
	{
		document.getElementById("b_one").style.background="url(image/1-2.PNG)";
		document.getElementById("b_four").style.background="url(image/4-1.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
		
		document.getElementById("img_one").src="image/1-2.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_realplaynum == 2)
	{
		document.getElementById("b_one").style.background="url(image/1-1.PNG)";
		document.getElementById("b_four").style.background="url(image/4-2.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
		
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-2.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_realplaynum == 3)
	{
		document.getElementById("b_one").style.background="url(image/1-1.PNG)";
		document.getElementById("b_four").style.background="url(image/4-1.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-2.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
		
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-2.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_realplaynum == 4)
	{
		document.getElementById("b_one").style.background="url(image/1-1.PNG)";
		document.getElementById("b_four").style.background="url(image/4-1.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-2.PNG)";
		
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-2.PNG";
	}
	
	if(b_record == 0)
	{
		document.getElementById("b_record_download_openfile").title="录像";
	}
	else if(b_record == 1)
	{
		document.getElementById("b_record_download_openfile").title="停止录像";
	}

	document.getElementById("b_channel").style.visibility="visible";
	document.getElementById("b_one").style.visibility="visible";
	document.getElementById("b_four").style.visibility="visible";
	document.getElementById("b_nine").style.visibility="visible";
	document.getElementById("b_sixteen").style.visibility="visible";
	document.getElementById("b_stop").style.visibility="visible";
	document.getElementById("b_capturepicture").style.visibility="visible";
	document.getElementById("b_record_download_openfile").style.visibility="visible";
	document.getElementById("b_pause").style.visibility="hidden";
	document.getElementById("b_slow").style.visibility="hidden";
	document.getElementById("b_fast").style.visibility="hidden";
	document.getElementById("b_frame").style.visibility="hidden";
	document.getElementById("img_volume").style.visibility="hidden";
	document.getElementById("b_volumeup").style.visibility="hidden";
	document.getElementById("b_volumedown_log").style.visibility="hidden";
	
	
	document.getElementById("IPCOcx").height= document.body.clientHeight-180;
	document.getElementById("IPCOcx").width= document.body.clientWidth-20;
	

	IPCOcx.RealPlay();
	m_currentselect=1;
	
	//IPCOcx.PreviewVoiceStart();

	IPCOcx.LocalSetSoundMode(0);
	IPCOcx.RemoteSetSoundMode(0);

}


function localplayback()
{

	document.getElementById("b_preview").style.background="#666666";
	document.getElementById("b_localplayback").style.background="#333333";
	document.getElementById("b_remoteplayback").style.background="#666666";
	document.getElementById("b_log").style.background="#666666";
	document.getElementById("b_setting").style.background="#666666";
	document.getElementById("b_four").disabled=false;
	document.getElementById("b_nine").disabled=false;
	document.getElementById("b_sixteen").disabled=false;
	
	if(b_localchannel == 0)
	{
		document.getElementById("b_channel").style.background="url(image/single2.PNG)";
		document.getElementById("b_channel").title="操作对单通道有效";
		document.getElementById("img_channel").src="image/single2.PNG";
	}
	else if(b_localchannel == 1)
	{
		document.getElementById("b_channel").style.background="url(image/all2.PNG)";
		document.getElementById("b_channel").title="操作对所有通道有效";
		document.getElementById("img_channel").src="image/all2.PNG";
	}
	
	if(m_localplaynum == 1)
	{
		document.getElementById("b_one").style.background="url(image/1-2.PNG)";
		document.getElementById("b_four").style.background="url(image/4-1.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
		
		document.getElementById("img_one").src="image/1-2.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_localplaynum == 2)
	{
		document.getElementById("b_one").style.background="url(image/1-1.PNG)";
		document.getElementById("b_four").style.background="url(image/4-2.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
		
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-2.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_localplaynum == 3)
	{
		document.getElementById("b_one").style.background="url(image/1-1.PNG)";
		document.getElementById("b_four").style.background="url(image/4-1.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-2.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
		
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-2.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_localplaynum == 4)
	{
		document.getElementById("b_one").style.background="url(image/1-1.PNG)";
		document.getElementById("b_four").style.background="url(image/4-1.PNG)";
		document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
		document.getElementById("b_sixteen").style.background="url(image/16-2.PNG)";
		
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-2.PNG";
	}
	document.getElementById("b_record_download_openfile").disabled=false;
	document.getElementById("b_record_download_openfile").style.background="url(image/dakaiwenjian2.PNG)";
	document.getElementById("b_record_download_openfile").title="打开文件";
	document.getElementById("img_record_download_openfile").src="image/dakaiwenjian2.PNG";

	document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian1.PNG)";
	document.getElementById("b_volumedown_log").title="音量减";
	document.getElementById("img_volumedown_log").src="image/yinliangjian1.PNG";

	document.getElementById("b_channel").style.visibility="visible";
	document.getElementById("b_one").style.visibility="visible";
	document.getElementById("b_four").style.visibility="visible";
	document.getElementById("b_nine").style.visibility="visible";
	document.getElementById("b_sixteen").style.visibility="visible";
	document.getElementById("b_stop").style.visibility="visible";
	document.getElementById("b_capturepicture").style.visibility="visible";
	document.getElementById("b_record_download_openfile").style.visibility="visible";
	document.getElementById("b_pause").style.visibility="visible";
	document.getElementById("b_slow").style.visibility="visible";
	document.getElementById("b_fast").style.visibility="visible";
	document.getElementById("b_frame").style.visibility="visible";
	document.getElementById("img_volume").style.visibility="visible";
	document.getElementById("b_volumeup").style.visibility="visible";
	document.getElementById("b_volumedown_log").style.visibility="visible";
	
	document.getElementById("IPCOcx").height= document.body.clientHeight-180;
	document.getElementById("IPCOcx").width= document.body.clientWidth-20;

	IPCOcx.PlayBackLocal();
	m_currentselect=2;
	
	IPCOcx.PreviewVoiceStop();
	IPCOcx.LocalSetSoundMode(4);
	IPCOcx.RemoteSetSoundMode(0);

}


function remoteplayback()
{
	
	document.getElementById("b_preview").style.background="#666666";
	document.getElementById("b_localplayback").style.background="#666666";
	document.getElementById("b_remoteplayback").style.background="#333333";
	document.getElementById("b_log").style.background="#666666";
	document.getElementById("b_setting").style.background="#666666";
	
	document.getElementById("img_four").src="image/4-1.PNG";
	document.getElementById("img_nine").src="image/9-1.PNG";
	document.getElementById("img_sixteen").src="image/16-1.PNG";
	
	document.getElementById("b_four").style.background="url(image/4-1.PNG)";
	document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
	document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
	document.getElementById("b_four").disabled=true;
	document.getElementById("b_nine").disabled=true;
	document.getElementById("b_sixteen").disabled=true;
	
	if(b_remotechannel == 0)
	{
		document.getElementById("b_channel").style.background="url(image/single2.PNG)";
		document.getElementById("b_channel").title="操作对单通道有效！";
		document.getElementById("img_channel").src="image/single2.PNG";
	}
	else if(b_remotechannel == 1)
	{
		document.getElementById("img_channel").src="image/all2.PNG";
		document.getElementById("b_channel").style.background="url(image/all2.PNG)";
		document.getElementById("b_channel").title="操作对所有通道有效！";
	}
	
	if(m_remoteplaynum == 1)
	{
		document.getElementById("img_one").src="image/1-2.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("b_one").style.background="url(image/1-2.PNG)";
		document.getElementById("b_four").style.background="url(image/4-1.PNG)";
	}

	/*
	else if(m_remoteplaynum == 2)
	{
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-2.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_remoteplaynum == 3)
	{
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-2.PNG";
		document.getElementById("img_sixteen").src="image/16-1.PNG";
	}
	else if(m_remoteplaynum == 4)
	{
		document.getElementById("img_one").src="image/1-1.PNG";
		document.getElementById("img_four").src="image/4-1.PNG";
		document.getElementById("img_nine").src="image/9-1.PNG";
		document.getElementById("img_sixteen").src="image/16-2.PNG";
	}
	*/
	document.getElementById("b_record_download_openfile").disabled=false;
	document.getElementById("b_record_download_openfile").style.background="url(image/xiazai2.PNG)";
	document.getElementById("b_record_download_openfile").title="下载";
	document.getElementById("b_volumedown_log").style.background="url(image/yinliangjian1.PNG)";
	document.getElementById("b_volumedown_log").title="音量减";
	document.getElementById("img_record_download_openfile").src="image/xiazai2.PNG";
	document.getElementById("img_volumedown_log").src="image/yinliangjian1.PNG";
	
	document.getElementById("b_channel").style.visibility="visible";
	document.getElementById("b_one").style.visibility="visible";
	document.getElementById("b_four").style.visibility="visible";
	document.getElementById("b_nine").style.visibility="visible";
	document.getElementById("b_sixteen").style.visibility="visible";
	document.getElementById("b_stop").style.visibility="visible";
	document.getElementById("b_capturepicture").style.visibility="visible";
	document.getElementById("b_record_download_openfile").style.visibility="visible";
	document.getElementById("b_pause").style.visibility="visible";
	document.getElementById("b_slow").style.visibility="visible";
	document.getElementById("b_fast").style.visibility="visible";
	document.getElementById("b_frame").style.visibility="visible";
	document.getElementById("img_volume").style.visibility="visible";
	document.getElementById("b_volumeup").style.visibility="visible";
	document.getElementById("b_volumedown_log").style.visibility="visible";

	document.getElementById("IPCOcx").height= document.body.clientHeight-180;
	document.getElementById("IPCOcx").width= document.body.clientWidth-20;

	IPCOcx.PlayBackRemote();
	m_currentselect=3;
	
	IPCOcx.PreviewVoiceStop();
	IPCOcx.LocalSetSoundMode(0);
	IPCOcx.RemoteSetSoundMode(4);

}


function log()
{
	
	document.getElementById("b_preview").style.background="#666666";
	document.getElementById("b_localplayback").style.background="#666666";
	document.getElementById("b_remoteplayback").style.background="#666666";
	document.getElementById("b_log").style.background="#333333";
	document.getElementById("b_setting").style.background="#666666";
	
	document.getElementById("b_volumedown_log").style.background="url(image/rizhi2.PNG)";
	document.getElementById("b_volumedown_log").title="导出日志";
	document.getElementById("img_volumedown_log").src="image/rizhi2.PNG";
	
	document.getElementById("b_channel").style.visibility="hidden";
	document.getElementById("b_one").style.visibility="hidden";
	document.getElementById("b_four").style.visibility="hidden";
	document.getElementById("b_nine").style.visibility="hidden";
	document.getElementById("b_sixteen").style.visibility="hidden";
	document.getElementById("b_stop").style.visibility="hidden";
	document.getElementById("b_capturepicture").style.visibility="hidden";
	document.getElementById("b_record_download_openfile").style.visibility="hidden";
	document.getElementById("b_pause").style.visibility="hidden";
	document.getElementById("b_slow").style.visibility="hidden";
	document.getElementById("b_fast").style.visibility="hidden";
	document.getElementById("b_frame").style.visibility="hidden";
	document.getElementById("img_volume").style.visibility="hidden";
	document.getElementById("b_volumeup").style.visibility="hidden";
	document.getElementById("b_volumedown_log").style.visibility="visible";
	
	document.getElementById("b_volumedown_log").disabled=false;
	
	document.getElementById("IPCOcx").height= document.body.clientHeight-180;
	document.getElementById("IPCOcx").width= document.body.clientWidth-20;

	IPCOcx.Log();
	m_currentselect=4;

	IPCOcx.LocalSetSoundMode(0);
	IPCOcx.RemoteSetSoundMode(0);
}

function setting()
{
	m_settingwndwidth = IPCOcx.GetWndWidth;
	m_settingwndheigh = IPCOcx.GetWndHeight;
	document.getElementById("b_preview").style.background="#666666";
	document.getElementById("b_localplayback").style.background="#666666";
	document.getElementById("b_remoteplayback").style.background="#666666";
	document.getElementById("b_log").style.background="#666666";
	document.getElementById("b_setting").style.background="#333333";

	document.getElementById("b_channel").style.visibility="hidden";
	document.getElementById("b_one").style.visibility="hidden";
	document.getElementById("b_four").style.visibility="hidden";
	document.getElementById("b_nine").style.visibility="hidden";
	document.getElementById("b_sixteen").style.visibility="hidden";
	document.getElementById("b_stop").style.visibility="hidden";
	document.getElementById("b_capturepicture").style.visibility="hidden";
	document.getElementById("b_record_download_openfile").style.visibility="hidden";
	document.getElementById("b_pause").style.visibility="hidden";
	document.getElementById("b_slow").style.visibility="hidden";
	document.getElementById("b_fast").style.visibility="hidden";
	document.getElementById("b_frame").style.visibility="hidden";
	document.getElementById("img_volume").style.visibility="hidden";
	document.getElementById("b_volumeup").style.visibility="hidden";
	document.getElementById("b_volumedown_log").style.visibility="hidden";
	
	document.getElementById("IPCOcx").height= m_settingwndheigh;
	document.getElementById("IPCOcx").width= m_settingwndwidth;
	
	
	
	IPCOcx.ParamSetting();
	m_currentselect=5;
	
	IPCOcx.LocalSetSoundMode(0);
	IPCOcx.RemoteSetSoundMode(0);
}



function Channel()
{
	if(m_currentselect == 1)
	{
		if(b_realplaychannel == 0)
		{
			IPCOcx.RealPlaySetOperateAll(true);
			document.getElementById("b_channel").style.background="url(image/all2.PNG)";
			document.getElementById("img_channel").src="image/all2.PNG";
			document.getElementById("b_channel").title="操作对所有通道有效";
			b_realplaychannel = 1;
		}
		else if(b_realplaychannel == 1)
		{
			IPCOcx.RealPlaySetOperateAll(false);
			document.getElementById("b_channel").style.background="url(image/single2.PNG)";
			document.getElementById("img_channel").src="image/single2.PNG";
			document.getElementById("b_channel").title="操作对单通道有效";
			b_realplaychannel = 0;
		}
	}
	else if(m_currentselect == 2)
	{
		if(b_localchannel == 0)
		{
			IPCOcx.LocalSetOperateAll(true);
			document.getElementById("b_channel").style.background="url(image/all2.PNG)";
			document.getElementById("img_channel").src="image/all2.PNG";
			document.getElementById("b_channel").title="操作对所有通道有效";
			b_localchannel = 1;
		}
		else if(b_localchannel == 1)
		{
			IPCOcx.LocalSetOperateAll(false);
			document.getElementById("b_channel").style.background="url(image/single2.PNG)";
			document.getElementById("img_channel").src="image/single2.PNG";
			document.getElementById("b_channel").title="操作对单通道有效";
			b_localchannel = 0;
		}
	}
	else if(m_currentselect == 3)
	{
		if(b_remotechannel == 0)
		{
			IPCOcx.RemoteSetOperateAll(true);
			document.getElementById("b_channel").style.background="url(image/all2.PNG)";
			document.getElementById("img_channel").src="image/all2.PNG";
			document.getElementById("b_channel").title="操作对所有通道有效";
			b_remotechannel = 1;
		}
		else if(b_remotechannel == 1)
		{
			IPCOcx.RemoteSetOperateAll(false);
			document.getElementById("b_channel").style.background="url(image/single2.PNG)";
			document.getElementById("img_channel").src="image/single2.PNG";
			document.getElementById("b_channel").title="操作对单通道有效";
			b_remotechannel = 0;
		}
	}
}


function SetMenu1()
{
	document.getElementById("b_one").style.background="url(image/1-2.PNG)";
	document.getElementById("b_four").style.background="url(image/4-1.PNG)";
	document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
	document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
	
	document.getElementById("img_one").src="image/1-2.PNG";
	document.getElementById("img_four").src="image/4-1.PNG";
	document.getElementById("img_nine").src="image/9-1.PNG";
	document.getElementById("img_sixteen").src="image/16-1.PNG";
	
	var mode = 1;

	if(m_currentselect == 1)
	{
		IPCOcx.RealPlayChangeMode(mode);
		m_realplaynum = 1;
	}
	else if(m_currentselect == 2)
	{
		IPCOcx.LocalPlayBackChangeMode(mode);
		m_localplaynum = 1;
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlayBackChangeMode(mode);
		m_remoteplaynum = 1;
	}
}

function SetMenu4()
{
	document.getElementById("b_one").style.background="url(image/1-1.PNG)";
	document.getElementById("b_four").style.background="url(image/4-2.PNG)";
	document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
	document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
	
	document.getElementById("img_one").src="image/1-1.PNG";
	document.getElementById("img_four").src="image/4-2.PNG";
	document.getElementById("img_nine").src="image/9-1.PNG";
	document.getElementById("img_sixteen").src="image/16-1.PNG";
	
	var mode = 2;
	
	if(m_currentselect == 1)
	{
		IPCOcx.RealPlayChangeMode(mode);
		m_realplaynum = 2;
	}
	else if(m_currentselect == 2)
	{
		IPCOcx.LocalPlayBackChangeMode(mode);
		m_localplaynum = 2;
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlayBackChangeMode(mode);
		m_remoteplaynum = 2;
	}
}

function SetMenu9()
{
	document.getElementById("b_one").style.background="url(image/1-1.PNG)";
	document.getElementById("b_four").style.background="url(image/4-1.PNG)";
	document.getElementById("b_nine").style.background="url(image/9-2.PNG)";
	document.getElementById("b_sixteen").style.background="url(image/16-1.PNG)";
	
	document.getElementById("img_one").src="image/1-1.PNG";
	document.getElementById("img_four").src="image/4-1.PNG";
	document.getElementById("img_nine").src="image/9-2.PNG";
	document.getElementById("img_sixteen").src="image/16-1.PNG";
	
	var mode = 3;
	
	if(m_currentselect == 1)
	{
		IPCOcx.RealPlayChangeMode(mode);
		m_realplaynum = 3;
	}
	else if(m_currentselect == 2)
	{
		IPCOcx.LocalPlayBackChangeMode(mode);
		m_localplaynum = 3;
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlayBackChangeMode(mode);
		m_remoteplaynum = 3;
	}
}
function SetMenu16()
{
	document.getElementById("b_one").style.background="url(image/1-1.PNG)";
	document.getElementById("b_four").style.background="url(image/4-1.PNG)";
	document.getElementById("b_nine").style.background="url(image/9-1.PNG)";
	document.getElementById("b_sixteen").style.background="url(image/16-2.PNG)";
	
	document.getElementById("img_one").src="image/1-1.PNG";
	document.getElementById("img_four").src="image/4-1.PNG";
	document.getElementById("img_nine").src="image/9-1.PNG";
	document.getElementById("img_sixteen").src="image/16-2.PNG";

	var mode = 4;

	if(m_currentselect == 1)
	{
		IPCOcx.RealPlayChangeMode(mode);
		m_realplaynum = 4;
	}
	else if(m_currentselect == 2)
	{
		IPCOcx.LocalPlayBackChangeMode(mode);
		m_localplaynum = 4;
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlayBackChangeMode(mode);
		m_remoteplaynum = 4;
	}
}

function CapturePicture()
{
	if(m_currentselect == 1)
	{
		IPCOcx.RealPlayCapturePicture();
	}
	else if(m_currentselect == 2)
	{
		IPCOcx.LocalCatchPic();
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemoteCatchPic();
	}
}



function Record_Download_Openfile()
{
	if(m_currentselect == 1)
	{
		
		if(b_record == 0)
		{
			IPCOcx.RealPlaySaveData();
			document.getElementById("b_record_download_openfile").title="停止录像";
			b_record = 1;
		}
		else if(b_record == 1)
		{
			IPCOcx.RealPlayStopSave();
			document.getElementById("b_record_download_openfile").title="正在录像";
			b_record = 0;
		}
	}
	else if (m_currentselect == 2)
	{
		IPCOcx.LocalOpenFile();
	}
	else if (m_currentselect == 3)
	{
		if(b_download == 0)
		{
			IPCOcx.Download();
		}
	}
}


function Stop()
{
	if(m_currentselect == 1)
	{
		IPCOcx.RealPlayStop();
	}
	else if(m_currentselect == 2)
	{
		IPCOcx.LocalPlayStop();
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlayStop();
	}
}

function Pause()
{
	if(m_currentselect == 2)
	{
		m_localplaymode = IPCOcx.LocalGetPlayMode;
		
		if(m_localplaymode == 0 || m_localplaymode == 3)
		{
			IPCOcx.LocalPlayRestart();
		}
		else
		{
			IPCOcx.LocalPlayPause();
		}
	}
	
	else if(m_currentselect == 3)
	{
		m_remoteplaymode = IPCOcx.RemoteGetPlayMode;

		if(m_remoteplaymode == 0 || m_remoteplaymode == 3)
		{
			IPCOcx.RemotePlayRestart();
		}
		else
		{
			IPCOcx.RemotePlayPause();
		}
	}
}
function Slow()
{
	if(m_currentselect == 2)
	{
		m_localplaymode = IPCOcx.LocalGetPlayMode;
		IPCOcx.LocalPlaySlow();
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlaySlow();
	}
}

function Fast()
{
	if(m_currentselect == 2)
	{
		m_localplaymode = IPCOcx.LocalGetPlayMode;
		IPCOcx.LocalPlayFast();
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlayFast();
	}
}


//var test= 0;
function frame()
{
	//test = test +1;
	//document.getElementById("test").value = test;
	
	if(m_currentselect == 2)
	{
		IPCOcx.LocalPlayFrame();
	}
	else if(m_currentselect == 3)
	{
		IPCOcx.RemotePlayFrame();
	}
	
}

function VolumeUp()
{
	//test =0;
	//document.getElementById("test").value = test;
	var m_currentvolume = -1;
	var m_setvolume = -1;
	if(m_currentselect == 2)
	{
		m_currentvolume = IPCOcx.LocalGetSoundMode();
		m_setvolume = m_currentvolume + 1;
		IPCOcx.LocalSetSoundMode(m_setvolume);
	}
	else if(m_currentselect == 3)
	{
		m_currentvolume = IPCOcx.RemoteGetSoundMode();
		m_setvolume = m_currentvolume + 1;
		IPCOcx.RemoteSetSoundMode(m_setvolume);
	}
}

function VolumeDown_Log()
{
	var m_currentvolume = -1;
	var m_setvolume = -1;
	if(m_currentselect == 2)
	{
		m_currentvolume = IPCOcx.LocalGetSoundMode();
		m_setvolume = m_currentvolume - 1;
		IPCOcx.LocalSetSoundMode(m_setvolume);
	}
	
	else if(m_currentselect == 3)
	{
		m_currentvolume = IPCOcx.RemoteGetSoundMode();
		m_setvolume = m_currentvolume - 1;
		IPCOcx.RemoteSetSoundMode(m_setvolume);
	}	
	
	else if(m_currentselect == 4)
	{
		IPCOcx.LogOut();
	}
}
