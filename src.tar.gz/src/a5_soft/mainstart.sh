#!/bin/sh

ulimit -c unlimited
export MALLOC_CHECK_=0
source /etc/profile

modprobe snd-soc-hbipc.ko
modprobe snd-soc-tlv320aic3x.ko

/usr/local/bin/reset_eeprom &
sleep 1

/usr/local/bin/hb_hard_test
/usr/local/bin/main &

mkdir /tmp/sflash
touch /tmp/sflash/ppp_recover_file

